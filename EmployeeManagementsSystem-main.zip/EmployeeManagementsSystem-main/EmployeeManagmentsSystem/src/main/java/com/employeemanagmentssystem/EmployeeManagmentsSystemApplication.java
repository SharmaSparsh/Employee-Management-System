package com.employeemanagmentssystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class EmployeeManagmentsSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagmentsSystemApplication.class, args);
	}

}
